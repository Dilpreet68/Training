package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Training;

public interface TrainingService {
	public ArrayList<Training> getTraining();

}
