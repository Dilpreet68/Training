package NavigateStepDefinition;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Bean.msgBean;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


/*
 * Test Class for msg.html page
 * 
 * 
 * 
 * */



public class Test {

	private WebDriver driver;
	private msgBean bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\Users\\\\chromedriver_win32\\\\chromedriver.exe" );
		driver= new ChromeDriver();
	}
	
	@Given("^User is on msg page$")
	public void user_is_on_msg_page() throws Throwable {
		driver.get("D:\\Users\\dilpkaur\\SPRING WORKSPACE\\RecipeRegistrationForm_0185707\\msg.html");
		bean = new msgBean(driver);
		Thread.sleep(2000);
	   
	}

	@When("^User is trying to open the recipe_class_registration page$")
	public void user_is_trying_to_open_the_recipe_class_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    bean.setLink("");
		
	}

	@Then("^opens the recipe_class_registration page$")
	public void opens_the_recipe_class_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String exmessage="Go Back to Registration";
		String acmessage=bean.getLink().getText();
		
		
		if(exmessage.equals(acmessage))//verifying hyperlink for navigating to Recipe_class_registration.html page
		{
			driver.get("D:\\Users\\dilpkaur\\SPRING WORKSPACE\\RecipeRegistrationForm_0185707\\Recipe_class_registration.html");
			
		}
		
		else
		{
			driver.get("D:\\Users\\dilpkaur\\SPRING WORKSPACE\\RecipeRegistrationForm_0185707\\msg.html");	
		}
		
		
	}
}
