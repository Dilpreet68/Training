package Bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class msgBean {

	/*
	 * Bean Class for msg.html page  
	 * 
	 * 
	 * 
	 * */
	
	
	WebDriver driver;
	@FindBy(name="link")
	@CacheLookup
	WebElement link;
	
	public msgBean(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}

	public WebElement getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link.sendKeys(link);;
	}
	
	
	
}
