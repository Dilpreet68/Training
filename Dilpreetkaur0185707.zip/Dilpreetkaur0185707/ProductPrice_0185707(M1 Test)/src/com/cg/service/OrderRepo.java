package com.cg.service;

import com.cg.bean.*;
public interface OrderRepo {
	
	public int saveOrder(Order bean) ;

}
