package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ProductDao;
import com.cg.entity.Product;
import com.cg.exception.ApplicationException;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{
@Autowired ProductDao dao;

//view all products
	@Transactional(readOnly=true)
	public List<Product> getall() {
		if(dao.findAll().isEmpty()) {
			throw new ApplicationException("No records Exist");
		}
		return dao.findAll();
	}
	
	
	//create product
	@Transactional
	public String addProduct(Product p) {
		if(dao.existsById(p.getProductId())) {
			throw new ApplicationException("Product with Id = " +p.getProductId()+" Already Exists");
		}
		else {
			dao.save(p);
			return "Product Added";
			}
	}
	
	//find by id 
	@Transactional(readOnly=true)
	public Product getById(String id) {
		Optional<Product> product=dao.findById(id);
		if(product.isPresent()) {
			return product.get();
		}
		else {
			throw new ApplicationException("No Product Exists with Id = "+id);
		}
	}
	//update product
	@Transactional
	public String update(Product p) {
		String id=p.getProductId();
		this.delete(id);
		this.addProduct(p);
		return "Product Updated";
	}
	
	
	//delete product
	@Transactional
	public String delete(String id) {
		 dao.delete(this.getById(id));
		 return "Product Deleted";
	}

}
