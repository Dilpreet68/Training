package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;

@RestController
public class Controller {
	
	Product p1= new Product("i01","Iphone","6s",45000.00);
	Product p2= new Product("s01","Samsung","Galaxy S9",55000.00);
	Product p3= new Product("m01","Motorola","Motto M7",29000.00);
	
	
	@Autowired ProductService service;
	@GetMapping(value="/products",produces= {"application/json"})
	public List<Product> getall() {
	
	
		
	
		service.addProduct(p1);
		service.addProduct(p2);
		service.addProduct(p3);
		
		return service.getall();
	}
	@PostMapping(value="/products/add",consumes={"application/json"})
	public String addProduct(@RequestBody Product product) {
		
		return service.addProduct(product);
	}
	@GetMapping(value="/find/{id}",produces= {"application/json"})
	public Product getById(@PathVariable String id) {
		
		return service.getById(id);
	}
	@PostMapping(value="/products/update",consumes= {"application/json"})
	public String update(@RequestBody Product product) {
		
		service.update(product);
		return "Product Updated";
	}
	@PostMapping(value="/delete/{id}")
	public String delete(@PathVariable String id) {
	
		service.delete(id);
		return "Product Deleted";
	}
	
	
}
