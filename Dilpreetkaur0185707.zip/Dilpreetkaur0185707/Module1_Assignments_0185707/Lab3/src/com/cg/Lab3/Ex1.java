package com.cg.Lab3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Ex1 {

	
	
	 static int getSecondSmallest(ArrayList<Integer> arr) {

			int min=0,k=0;
			Collections.sort(arr);
			for(int i=0;i<arr.size();i++)
			{
				if(k==arr.get(i))
					{
					arr.remove(i);
					i--;
					}
				else
					k=arr.get(i);
			}
			if(arr.size()>1)
			min=arr.get(1);
			else
				min=0;
			return min;
		}
	
	
	public static void main(String args[])
	{
		Scanner scan = new Scanner(System.in);
		int n,num=-1;
		ArrayList<Integer> a=new ArrayList<Integer>();
		System.out.println("Enter the Size of Array ");
		n=scan.nextInt();
		System.out.println("Enter the Elements");
		for(int i=0;i<n;i++)
		{
			a.add(scan.nextInt());
		}
		num=getSecondSmallest(a);
		if (num==-1||num==0) 
			System.out.println("No Second Lowest Element");
		else
			System.out.println("Second Smallest Number is: "+num);
			
	}



}
 