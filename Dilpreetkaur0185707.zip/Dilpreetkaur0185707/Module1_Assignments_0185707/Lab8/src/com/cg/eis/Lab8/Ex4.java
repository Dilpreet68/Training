package com.cg.eis.Lab8;

	import java.io.*;
	class Ex4
	{
	public static void main(String args[])
	{
	File file=new File("Libraries\\Documents\\Dilpreetsql");
	System.out.println("file name"+file.getName());
	System.out.println("path"+file.getPath());
	System.out.println("parent"+file.getParent());
	System.out.println(file.exists());
	System.out.println(file.canRead());
	System.out.println(file.canWrite());
	System.out.println(file.isDirectory());
	System.out.println(file.isFile());
	
	System.out.println(file.length());
	
	}
	}


