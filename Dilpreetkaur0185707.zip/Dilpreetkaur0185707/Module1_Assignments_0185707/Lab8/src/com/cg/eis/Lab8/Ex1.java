package com.cg.eis.Lab8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Ex1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String nums="";
		System.out.println("Enter string of numbers");
		nums=br.readLine();
		int sum = 0;
        StringTokenizer token = new StringTokenizer(nums," ");
        while(token.hasMoreTokens()){
            String element = token.nextToken();
            System.out.println(element);
            sum = sum + Integer.parseInt(element);
        }
       


	    System.out.println(" ");
	    System.out.println("=========================");
		System.out.println("Sum :- "+sum);	
		System.out.println("==========================");
}
}