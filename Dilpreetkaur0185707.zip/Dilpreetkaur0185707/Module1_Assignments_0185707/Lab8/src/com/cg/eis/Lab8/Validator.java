package com.cg.eis.Lab8;

public interface Validator {
	
	
	String namepattern ="[a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-z]*+[_]+[j]+[o]+[b]";
	//salary any double
	String salary="[0-9]*+[.]*+[0-9]*";
	
	public static boolean validatedata(String data, String pattern)
	{
		return data.matches(pattern);
	}

}
