package com.cg.Lab1;

import java.util.Scanner;

public class Ex1 {
	 static int calculateSum(int n)
	{
		int sum=0;
		
		for(int i=1;i<=n;i++)
		{
			if(i%3==0||i%5==0)
			{
				sum=sum+i;
			}
		}
		return sum;
	}
	public static void main(String args[])
	{
		int n,sum=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Number:-");
		n=scan.nextInt();
		sum=calculateSum(n);
		System.out.println("Sum = "+sum);
	}
	

	
}
