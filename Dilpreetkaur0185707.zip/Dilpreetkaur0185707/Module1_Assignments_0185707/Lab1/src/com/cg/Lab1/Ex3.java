package com.cg.Lab1;

import java.io.IOException;
import java.util.Scanner;

public class Ex3 {
	
	
	
	
	 static boolean checkNumber(int n) {
		do
		{
		int b=0,c=0;
		b=n%10;
		n=n/10;
		c=n%10;
		if(c>b)
			return false;
		}while(n>0);
		return true;
	}
	
	
	
	
	public static void main(String[] args) throws IOException 
	{
		int n;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Number:-");
		n=scan.nextInt();
		boolean b=checkNumber(n);
		if(b==true)
			System.out.println("Number is in Increasing Order");
		else
			System.out.println("Number is not in Increasing Order");
		
	}

	
}
