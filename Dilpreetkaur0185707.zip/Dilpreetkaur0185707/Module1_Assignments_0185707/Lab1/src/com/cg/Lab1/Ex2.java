package com.cg.Lab1;

import java.util.Scanner;
import java.io.IOException;
import java.lang.*;


public class Ex2 {
	
	static int calcualteDifference(int n) {
		int diff=0,sum1=0,sum2=0;
		for(int i=1;i<=n;i++)
		{
			sum1=sum1+(int)Math.pow(i,2);
			sum2=sum2+i;
		}
		sum2=(int)Math.pow(sum2,2);
		diff=sum1-sum2;
		return diff;
	}
	
	
	public static void main(String args[]) throws IOException
	{
		int n;
		int diff=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter Number:-");
		n=scan.nextInt();
		diff=calcualteDifference(n);
		System.out.println("Difference = "+diff);
	}

	
}
