package com.cg.Lab1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Lab1test {

	@Test
	void testcalculateSum() {
		
		Ex1 ob = new Ex1();
		assertEquals(33,ob.calculateSum(11));
	}
	
	@Test
	void testcalculateDifference() {
		
		Ex2 ob = new Ex2();
		assertEquals(-170,ob.calcualteDifference(5));
	}

	@Test
	void testcheckNumber() {
		
		Ex3 ob = new Ex3();
		assertEquals(true,ob.checkNumber(14456));
	}
	
	
	@Test
	void testcheckNumber2() {
		
		Ex4 ob = new Ex4();
		assertEquals(true,ob.checkNumber2(256));
	}

}
