package com.cg.Lab5;

public interface Validator {
	
	String namepattern ="[a-zA-Z]*+[']*[.]*[ ]*+[a-zA-Z]*+[ ]*+[a-zA-Z]*";
	//may be like ------D'Souza,ram,raman gupta,----------
	
	String agepattern="[0-9]*+[.]*+[0-9]*";
	//may be like -----------15,10,9,9.5,--------
	
	String salarypattern="[0-9]*+[.]*+[0-9]*";
	public static boolean validatedata(String data, String pattern)
	{
		return data.matches(pattern);
	}

}
