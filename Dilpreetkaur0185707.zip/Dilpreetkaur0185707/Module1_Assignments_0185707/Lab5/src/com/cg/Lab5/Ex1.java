package com.cg.Lab5;

import javax.swing.*;    
import java.awt.event.*;    
class Ex1 extends JFrame implements ActionListener{    
JRadioButton rb11,rb22,rb33;    
JButton b;    
Ex1(){      
rb11=new JRadioButton("Red");    
rb11.setBounds(100,50,100,30);      
rb22=new JRadioButton("Yellow");    
rb22.setBounds(100,100,100,30); 
rb33=new JRadioButton("Green");    
rb33.setBounds(100,150,100,30);
ButtonGroup bg=new ButtonGroup();    
bg.add(rb11);bg.add(rb22);bg.add(rb33);    
b=new JButton("click");    
b.setBounds(100,200,80,30);    
b.addActionListener(this);    
add(rb11);add(rb22);add(rb33);add(b);    
setSize(300,300);    
setLayout(null);    
setVisible(true);    
}    
public void actionPerformed(ActionEvent e){    
if(rb11.isSelected()){    
JOptionPane.showMessageDialog(this,"Stop");    
}    
if(rb22.isSelected()){    
JOptionPane.showMessageDialog(this,"Ready");    
}  
if(rb33.isSelected()){    
JOptionPane.showMessageDialog(this,"Go");    
} 
}    
public static void main(String args[]){    
new Ex1();    
}}   
