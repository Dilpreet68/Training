package com.cg.pl;

abstract class WrittenItem extends Item {

	private String author;
public WrittenItem() {
	// TODO Auto-generated constructor stub
}
	public WrittenItem(int id, String title, String author, int noCopies) {
	super(id,title,noCopies);
	this.author=author;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
}
