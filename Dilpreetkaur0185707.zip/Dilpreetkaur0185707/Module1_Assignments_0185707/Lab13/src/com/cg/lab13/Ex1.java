package com.cg.lab13;

import java.lang.Math;
import java.util.Scanner;


interface printExpression{
	public long print(int x,int y);
}

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printExpression pe=(x,y)->(int) Math.pow(x, y);
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter number...");
		int x= scan.nextInt();
		System.out.println("Enter power...");
		int y= scan.nextInt();
				long e= pe.print(x,y);
		System.out.println("Answer :"+e);
	}

}