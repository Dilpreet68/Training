import {Component} from '@angular/core';

@Component({
    selector:'show-pro',
    templateUrl:'app.show.html'
})
export class ShowProductComponent
{

}