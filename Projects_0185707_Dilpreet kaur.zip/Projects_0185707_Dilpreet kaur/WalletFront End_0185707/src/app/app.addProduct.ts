import{Component} from '@angular/core';


@Component
(
    {
        selector:'add-pro',
        template:'<h1>In Add Product Component......</h1><show-pro></show-pro>'
                
    }
)

export class AddProductComponent{




}